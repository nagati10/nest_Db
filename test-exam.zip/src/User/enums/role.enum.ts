export enum Role {
  USER = 'user',
  ADMIN = 'admin',
}